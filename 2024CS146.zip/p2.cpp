#include <iostream>
using namespace std;

int main() {
    int a,b,c;
cout<<"Enter number of minutes"<<endl;
cin>>a;
cout<<"Enter number of FPS"<<endl;
cin>>b;
c=a*60*b;
cout<<"Toltal number of frames are "<<c;
return 0;
}