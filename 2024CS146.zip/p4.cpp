#include <iostream>
using namespace std;

int main() {
int a,b,c;
cout<<"Enter imposter count."<<endl;
cin>>a;
cout<<"Enter player count."<<endl;
cin>>b;
c=100*a/b;
cout<<"The percentage of imposter is "<<c<<"% ."<<endl;
return 0;
}