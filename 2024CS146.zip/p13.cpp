#include <iostream>
using namespace std;

int main() {
int a,b;
cout<<"Enter the first number: "<<endl;
cin>>a;
cout<<"Enter the second number: "<<endl;
cin>>b;
a=a+b;
cout<<"Enter the third number: "<<endl;
cin>>b;
a=a+b;
cout<<"Enter the fourth number: "<<endl;
cin>>b;
a=a+b;
cout<<"Enter the fifth number: "<<endl;
cin>>b;
a=a+b;
cout<<"The sum of five integers is "<<a;
return 0;
}