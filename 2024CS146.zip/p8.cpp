#include <iostream>
using namespace std;

int main() {
    float a,b,c,d;
    int e;
cout<<"Enter fruit price per kilogram in coins."<<endl;
cin>>a;
cout<<"Enter vegetable price per kilogram in coins."<<endl;
cin>>b;
cout<<"Enter total kilograms of fruits."<<endl;
cin>>c;
cout<<"Enter total kilograms of vegetables."<<endl;
cin>>d;
e=a*c/1.94+b*d/1.94;
cout<<"Total earnings in PKR are "<<e<<endl;
return 0;
}