#include <iostream>
using namespace std;

int main() {
    float a,b,c,d;
cout<<"Enter Initial Velocity in (ms^-1)"<<endl;
cin>>a;
cout<<"Enter Acceleration in (ms^-2)"<<endl;
cin>>b;
cout<<"Enter time in (s)"<<endl;
cin>>c;
d=a+b*c;
cout<<"Final Velocity is "<<d<<"ms^-1"<<endl;
return 0;
}