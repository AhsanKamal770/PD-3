#include <iostream>
using namespace std;

int main() {
    string s;
    int a,b,c,d,e,f,g,h;
cout<<"Enter movie name."<<endl;
cin>>s;
cout<<"Enter adult ticket price"<<endl;
cin>>a;
cout<<"Enter child ticket price."<<endl;
cin>>b;
cout<<"Enter number of adults tickets sold."<<endl;
cin>>c;
cout<<"Enter number of child tickets sold."<<endl;
cin>>d;
cout<<"Enter percentage that is to be donated to charity. "<<endl;
cin>>e;
g=a*c+b*d;
e=g*e/100;
f=g-e;
cout<<"Total income from ticket sales is $"<<g<<endl;
cout<<"Donation to charity is $"<<e<<endl;
cout<<"Amount remainig after donatiion is $"<<f<<endl;
return 0;
}