#include <iostream>
using namespace std;

int main() {
   unsigned int a,b;
cout<<"Enter the number of sides of Polygon. "<<endl;
cin>>a;
b=(a-2)*180;
cout<<"Sum of interior angles of "<<a<<"-sided polygon is "<<b;
return 0;
}