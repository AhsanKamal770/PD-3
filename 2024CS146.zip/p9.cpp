#include <iostream>
using namespace std;

int main() {
int a,b,c,d,e,f;
cout<<"Enter a four digit number."<<endl;
cin>>a;
b=a/1000;
c=(a/100)%10;
d=(a/10)%10;
e=a%10;
f=b+c+d+e;
cout<<"The sum of individual digits is "<<f<<endl;
return 0;
}