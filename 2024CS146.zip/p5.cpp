#include <iostream>
using namespace std;

int main() {
    string a;
    int b,c;
cout<<"Enter your name: "<<endl;
cin>>a;
cout<<"Enter your target: "<<endl;
cin>>b;
c=b*15;
cout<<"you will require "<<c<<" days to lose "<<b<<"kgs weight.";

return 0;
}