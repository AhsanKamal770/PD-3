#include <iostream>
using namespace std;

int main() {
    short a,b,c,d;
cout<<"Enter the person's age."<<endl;
cin>>a;
cout<<"Enter number of times they have moved."<<endl;
cin>>b;
c=b+1;
d=a/c;
cout<<"Average number of years lived in same house are "<<d<<endl;
return 0;
}