#include <iostream>
using namespace std;

int main() {
    int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,b,c,d,e;
cout<<"Number 1 "<<endl;
cin>>a1;
cout<<"Number 2 "<<endl;
cin>>a2;
cout<<"Number 3 "<<endl;
cin>>a3;
cout<<"Number 4 "<<endl;
cin>>a4;
cout<<"Number 5 "<<endl;
cin>>a5;
cout<<"Number 6 "<<endl;
cin>>a6;
cout<<"Number 7 "<<endl;
cin>>a7;
cout<<"Number 8 "<<endl;
cin>>a8;
cout<<"Number 9 "<<endl;
cin>>a9;
cout<<"Number 10"<<endl;
cin>>a10;
cout<<"Number 11"<<endl;
cin>>a11;
cout<<"Number 12"<<endl;
cin>>a12;
cout<<"Number 13"<<endl;
cin>>a[13];
cout<<"Number 14"<<endl;
cin>>a14;
cout<<"Number 15"<<endl;
    cin>>a15;
b=a1+a2+a3+a4+a5;
c=a6*a7*a8*a9*a10;
d=a11-a12-a13-a14-a15;
e=b+c-d;
cout<<"The result is "<<e<<endl;
return 0;
}