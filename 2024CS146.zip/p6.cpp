#include <iostream>
using namespace std;

int main() {
    int a,b,c,d,e;
cout<<"Enter the weight of bag in pounds."<<endl;
cin>>a;
cout<<"Enter the cost of bag in dollars. "<<endl;
cin>>b;
cout<<"Enter the area in sqft that can bo covered with one bag."<<endl;
cin>>c;
d=b/a;
e=b/c;
cout<<"Cost of fertilizer per pound is $"<<d<<endl;
cout<<"Cost of fertilizer per sqft is $"<<e<<endl;    
return 0;
}