#include <iostream>
using namespace std;

int main() {
    int a,b,c,d;
cout<<"Enter number of square matres you can paint."<<endl;
cin>>a;
cout<<"Enter Length of single wall. "<<endl;
cin>>b;
cout<<"Enter Width of single wall."<<endl;
cin>>c;
d=a/(b*c);
cout<<"Number of walls you can paint are "<<d<<endl;

return 0;
}